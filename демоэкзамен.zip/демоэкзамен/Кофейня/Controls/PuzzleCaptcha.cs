using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Кофейня.Controls
{
    /// <summary>
    /// Интерактивная пазл-капча: пользователь перетаскивает фрагменты на нужные места.
    /// </summary>
    public class PuzzleCaptcha : UserControl
    {
        public event EventHandler PuzzleSolved;
        public event EventHandler PuzzleFailed;

        private const int Cols      = 2;
        private const int Rows      = 2;
        private const int PieceSize = 100;

        private List<PuzzlePiece> _pieces  = new List<PuzzlePiece>();
        private PuzzlePiece       _dragging;
        private Point             _dragOffset;
        private bool              _isSolved;

        public bool IsSolved => _isSolved;

        public PuzzleCaptcha()
        {
            DoubleBuffered = true;
            Width          = PieceSize * Cols * 2 + 20;
            Height         = PieceSize * Rows + 40;
            BackColor      = Color.WhiteSmoke;
        }

        public void LoadPieces(Image[] images)
        {
            _pieces.Clear();
            _isSolved = false;

            var rng        = new Random();
            int slotAreaX  = 10;
            int bankAreaX  = PieceSize * Cols + 30;

            var correctPositions = new Point[]
            {
                new Point(slotAreaX,             10),
                new Point(slotAreaX + PieceSize, 10),
                new Point(slotAreaX,             10 + PieceSize),
                new Point(slotAreaX + PieceSize, 10 + PieceSize),
            };

            int[] order = { 0, 1, 2, 3 };
            for (int i = order.Length - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                int tmp = order[i]; order[i] = order[j]; order[j] = tmp;
            }

            for (int i = 0; i < images.Length && i < 4; i++)
            {
                int col      = order[i] % Cols;
                int row      = order[i] / Cols;
                var startPos = new Point(bankAreaX + col * PieceSize, 10 + row * PieceSize);

                _pieces.Add(new PuzzlePiece
                {
                    Image         = images[i],
                    CorrectSlot   = correctPositions[i],
                    CurrentBounds = new Rectangle(startPos, new Size(PieceSize, PieceSize)),
                    Index         = i
                });
            }

            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;

            int slotAreaX = 10;
            for (int r = 0; r < Rows; r++)
                for (int c = 0; c < Cols; c++)
                    g.DrawRectangle(Pens.Gray,
                        slotAreaX + c * PieceSize, 10 + r * PieceSize,
                        PieceSize, PieceSize);

            g.DrawString("Перетащите →", Font, Brushes.Gray,
                PieceSize * Cols + 30, Height - 20);

            foreach (var piece in _pieces)
            {
                if (piece == _dragging) continue;
                g.DrawImage(piece.Image, piece.CurrentBounds);
                g.DrawRectangle(Pens.DarkGray, piece.CurrentBounds);
            }

            if (_dragging != null)
            {
                g.DrawImage(_dragging.Image, _dragging.CurrentBounds);
                g.DrawRectangle(Pens.Blue, _dragging.CurrentBounds);
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            foreach (var piece in _pieces)
            {
                if (!piece.CurrentBounds.Contains(e.Location)) continue;
                _dragging   = piece;
                _dragOffset = new Point(e.X - piece.CurrentBounds.X, e.Y - piece.CurrentBounds.Y);
                break;
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_dragging == null) return;
            _dragging.CurrentBounds = new Rectangle(
                e.X - _dragOffset.X, e.Y - _dragOffset.Y, PieceSize, PieceSize);
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (_dragging == null) return;
            SnapToSlotIfNear(_dragging);
            _dragging = null;
            Invalidate();
        }

        private void SnapToSlotIfNear(PuzzlePiece piece)
        {
            int snapDistance = PieceSize / 2;
            var center = new Point(
                piece.CurrentBounds.X + PieceSize / 2,
                piece.CurrentBounds.Y + PieceSize / 2);
            var slotCenter = new Point(
                piece.CorrectSlot.X + PieceSize / 2,
                piece.CorrectSlot.Y + PieceSize / 2);

            double dist = Math.Sqrt(
                Math.Pow(center.X - slotCenter.X, 2) +
                Math.Pow(center.Y - slotCenter.Y, 2));

            if (dist < snapDistance)
                piece.CurrentBounds = new Rectangle(piece.CorrectSlot, new Size(PieceSize, PieceSize));
        }

        public void CheckSolution()
        {
            foreach (var piece in _pieces)
            {
                if (piece.CurrentBounds.Location != piece.CorrectSlot)
                {
                    _isSolved = false;
                    PuzzleFailed?.Invoke(this, EventArgs.Empty);
                    return;
                }
            }
            _isSolved = true;
            PuzzleSolved?.Invoke(this, EventArgs.Empty);
        }

        private class PuzzlePiece
        {
            public Image     Image         { get; set; }
            public Point     CorrectSlot   { get; set; }
            public Rectangle CurrentBounds { get; set; }
            public int       Index         { get; set; }
        }
    }
}