using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Кофейня.Entities;

namespace Кофейня.Data
{
    public static class DatabaseHelper
    {
        private static readonly string ConnectionString =
            "Server=localhost;Database=Производство;Integrated Security=True;"; 
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        public static User GetUserByLogin(string login)
        {
            const string query = "SELECT Id, Login, Password, Role, IsBlocked, FailedAttempts " +
                                  "FROM Пользователи WHERE Login = @Login";
            try
            {
                using (var connection = GetConnection())
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read()) return null;
                        return new User
                        {
                            Id             = reader.GetInt32(0),
                            Login          = reader.GetString(1),
                            Password       = reader.GetString(2),
                            Role           = reader.GetString(3),
                            IsBlocked      = reader.GetBoolean(4),
                            FailedAttempts = reader.GetInt32(5)
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public static void UpdateFailedAttempts(int userId, int attempts, bool isBlocked)
        {
            const string query = "UPDATE Пользователи SET FailedAttempts = @Attempts, " +
                                  "IsBlocked = @IsBlocked WHERE Id = @Id";
            ExecuteNonQuery(query,
                new SqlParameter("@Attempts",  attempts),
                new SqlParameter("@IsBlocked", isBlocked),
                new SqlParameter("@Id",        userId));
        }

        public static void ResetFailedAttempts(int userId)
        {
            const string query = "UPDATE Пользователи SET FailedAttempts = 0, IsBlocked = 0 WHERE Id = @Id";
            ExecuteNonQuery(query, new SqlParameter("@Id", userId));
        }

        public static bool LoginExists(string login)
        {
            const string query = "SELECT COUNT(1) FROM Пользователи WHERE Login = @Login";
            try
            {
                using (var connection = GetConnection())
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    connection.Open();
                    return (int)command.ExecuteScalar() > 0;
                }
            }
            catch { return false; }
        }

        public static void AddUser(string login, string password, string role)
        {
            const string query = "INSERT INTO Пользователи (Login, Password, Role, IsBlocked, FailedAttempts) " +
                                  "VALUES (@Login, @Password, @Role, 0, 0)";
            ExecuteNonQuery(query,
                new SqlParameter("@Login",    login),
                new SqlParameter("@Password", password),
                new SqlParameter("@Role",     role));
        }

        public static DataTable GetAllUsers()
        {
            const string query = "SELECT Id, Login, Role, IsBlocked FROM Пользователи";
            var table = new DataTable();
            try
            {
                using (var connection = GetConnection())
                using (var adapter = new SqlDataAdapter(query, connection))
                {
                    adapter.Fill(table);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователей:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return table;
        }

        public static void UnblockUser(int userId)
        {
            const string query = "UPDATE Пользователи SET IsBlocked = 0, FailedAttempts = 0 WHERE Id = @Id";
            ExecuteNonQuery(query, new SqlParameter("@Id", userId));
        }

        public static void UpdateUser(int userId, string login, string role)
        {
            const string query = "UPDATE Пользователи SET Login = @Login, Role = @Role WHERE Id = @Id";
            ExecuteNonQuery(query,
                new SqlParameter("@Login", login),
                new SqlParameter("@Role",  role),
                new SqlParameter("@Id",    userId));
        }

        private static void ExecuteNonQuery(string query, params SqlParameter[] parameters)
        {
            try
            {
                using (var connection = GetConnection())
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка выполнения операции:\n" + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}