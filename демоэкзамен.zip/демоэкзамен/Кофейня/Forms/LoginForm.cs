using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Кофейня.Controls;
using Кофейня.Data;
using Кофейня.Entities;

namespace Кофейня.Forms
{
    public class LoginForm : Form
    {
        private TextBox       _loginTextBox;
        private TextBox       _passwordTextBox;
        private Button        _loginButton;
        private Button        _checkPuzzleButton;
        private Label         _loginLabel;
        private Label         _passwordLabel;
        private Label         _captchaLabel;
        private PuzzleCaptcha _puzzleCaptcha;

        private bool _puzzlePassed;
        private int  _totalFailedAttempts;

        public LoginForm()
        {
            InitializeComponent();
            LoadPuzzle();
        }

        private void InitializeComponent()
        {
            Text            = "Кофейня Тёмная Материя — Авторизация";
            MinimumSize     = new Size(520, 540);
            Size            = new Size(520, 580);
            StartPosition   = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox     = false;
            BackColor       = Color.FromArgb(245, 245, 245);

            _loginLabel = new Label
            {
                Text      = "Логин:",
                Location  = new Point(20, 20),
                Size      = new Size(80, 24),
                TextAlign = ContentAlignment.MiddleRight
            };

            _loginTextBox = new TextBox
            {
                Location  = new Point(110, 20),
                Size      = new Size(360, 24),
                TabIndex  = 0,
                MaxLength = 100
            };

            _passwordLabel = new Label
            {
                Text      = "Пароль:",
                Location  = new Point(20, 55),
                Size      = new Size(80, 24),
                TextAlign = ContentAlignment.MiddleRight
            };

            _passwordTextBox = new TextBox
            {
                Location     = new Point(110, 55),
                Size         = new Size(360, 24),
                PasswordChar = '●',
                TabIndex     = 1,
                MaxLength    = 100
            };

            _captchaLabel = new Label
            {
                Text      = "Капча — соберите пазл и нажмите «Проверить»:",
                Location  = new Point(20, 95),
                Size      = new Size(460, 20),
                ForeColor = Color.DimGray
            };

            _puzzleCaptcha = new PuzzleCaptcha
            {
                Location = new Point(20, 120),
                TabIndex = 2
            };
            _puzzleCaptcha.PuzzleSolved += OnPuzzleSolved;
            _puzzleCaptcha.PuzzleFailed += OnPuzzleFailed;

            _checkPuzzleButton = new Button
            {
                Text     = "Проверить пазл",
                Location = new Point(20, 360),
                Size     = new Size(150, 32),
                TabIndex = 3
            };
            _checkPuzzleButton.Click += (s, e) => _puzzleCaptcha.CheckSolution();

            _loginButton = new Button
            {
                Text      = "Войти",
                Location  = new Point(390, 360),
                Size      = new Size(100, 32),
                TabIndex  = 4,
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            _loginButton.Click += OnLoginClick;

            Controls.AddRange(new Control[]
            {
                _loginLabel, _loginTextBox,
                _passwordLabel, _passwordTextBox,
                _captchaLabel, _puzzleCaptcha,
                _checkPuzzleButton, _loginButton
            });

            _loginTextBox.KeyDown    += (s, e) => { if (e.KeyCode == Keys.Enter) OnLoginClick(s, e); };
            _passwordTextBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) OnLoginClick(s, e); };
        }

        private void LoadPuzzle()
        {
            string resourcesPath = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory, "Resources");

            try
            {
                var images = new Image[]
                {
                    Image.FromFile(Path.Combine(resourcesPath, "1.png")),
                    Image.FromFile(Path.Combine(resourcesPath, "2.png")),
                    Image.FromFile(Path.Combine(resourcesPath, "3.png")),
                    Image.FromFile(Path.Combine(resourcesPath, "4.png")),
                };
                _puzzleCaptcha.LoadPieces(images);
            }
            catch
            {
                MessageBox.Show(
                    "Не удалось загрузить изображения пазла.\nУбедитесь, что папка Resources содержит файлы 1.png–4.png.",
                    "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OnPuzzleSolved(object sender, EventArgs e)
        {
            _puzzlePassed = true;
            MessageBox.Show("Пазл собран верно! Теперь введите логин и пароль.",
                "Капча пройдена", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OnPuzzleFailed(object sender, EventArgs e)
        {
            _puzzlePassed = false;
            RegisterFailedAttempt(null, "Пазл собран неверно. Попробуйте ещё раз.");
        }

        private void OnLoginClick(object sender, EventArgs e)
        {
            string login    = _loginTextBox.Text.Trim();
            string password = _passwordTextBox.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show(
                    "Поля «Логин» и «Пароль» обязательны для заполнения.\nЗаполните оба поля и повторите попытку.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!_puzzlePassed)
            {
                MessageBox.Show(
                    "Сначала пройдите проверку капчи — соберите пазл и нажмите «Проверить пазл».",
                    "Капча не пройдена", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            User user = DatabaseHelper.GetUserByLogin(login);

            if (user == null || user.Password != password)
            {
                RegisterFailedAttempt(user,
                    "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные");
                return;
            }

            if (user.IsBlocked)
            {
                MessageBox.Show("Вы заблокированы. Обратитесь к администратору.",
                    "Доступ запрещён", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DatabaseHelper.ResetFailedAttempts(user.Id);
            MessageBox.Show("Вы успешно авторизовались.",
                "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (user.Role == "Администратор")
            {
                new AdminForm(user).Show();
            }
            else
            {
                MessageBox.Show($"Добро пожаловать, {user.Login}!\nРоль: {user.Role}",
                    "Рабочий стол", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Hide();
        }

        private void RegisterFailedAttempt(User user, string message)
        {
            _totalFailedAttempts++;

            if (user != null)
            {
                int  newAttempts  = user.FailedAttempts + 1;
                bool shouldBlock  = newAttempts >= 3;
                DatabaseHelper.UpdateFailedAttempts(user.Id, newAttempts, shouldBlock);

                if (shouldBlock)
                {
                    MessageBox.Show("Вы заблокированы. Обратитесь к администратору.",
                        "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            MessageBox.Show(message, "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (_totalFailedAttempts >= 3)
            {
                _loginButton.Enabled       = false;
                _checkPuzzleButton.Enabled = false;
                _puzzlePassed              = false;
                MessageBox.Show("Слишком много неудачных попыток. Перезапустите приложение.",
                    "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _puzzlePassed = false;
                LoadPuzzle();
            }
        }
    }
}