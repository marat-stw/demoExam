using System;
using System.Drawing;
using System.Windows.Forms;

namespace Кофейня.Forms
{
    public class UserEditDialog : Form
    {
        public string UserLogin    { get; private set; }
        public string UserPassword { get; private set; }
        public string UserRole     { get; private set; }

        private TextBox  _loginBox;
        private TextBox  _passwordBox;
        private ComboBox _roleCombo;
        private Label    _passwordLabel;
        private Button   _okButton;
        private Button   _cancelButton;
        private bool     _isEdit;

        public UserEditDialog(string existingLogin = null, string existingRole = null)
        {
            _isEdit = existingLogin != null;
            InitializeComponent();

            if (!_isEdit) return;

            _loginBox.Text          = existingLogin;
            _roleCombo.SelectedItem = existingRole;
            _passwordBox.Visible    = false;
            _passwordLabel.Visible  = false;
            Text = "Редактировать пользователя";
        }

        private void InitializeComponent()
        {
            Text            = "Добавить пользователя";
            Size            = new Size(340, 240);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition   = FormStartPosition.CenterParent;
            MaximizeBox     = false;
            MinimizeBox     = false;

            var loginLabel = new Label
            {
                Text      = "Логин:",
                Location  = new Point(20, 20),
                Size      = new Size(80, 24),
                TextAlign = ContentAlignment.MiddleRight
            };

            _loginBox = new TextBox
            {
                Location  = new Point(110, 20),
                Size      = new Size(190, 24),
                TabIndex  = 0,
                MaxLength = 100
            };

            _passwordLabel = new Label
            {
                Text      = "Пароль:",
                Location  = new Point(20, 55),
                Size      = new Size(80, 24),
                TextAlign = ContentAlignment.MiddleRight
            };

            _passwordBox = new TextBox
            {
                Location     = new Point(110, 55),
                Size         = new Size(190, 24),
                PasswordChar = '●',
                TabIndex     = 1,
                MaxLength    = 100
            };

            var roleLabel = new Label
            {
                Text      = "Роль:",
                Location  = new Point(20, 90),
                Size      = new Size(80, 24),
                TextAlign = ContentAlignment.MiddleRight
            };

            _roleCombo = new ComboBox
            {
                Location      = new Point(110, 90),
                Size          = new Size(190, 24),
                DropDownStyle = ComboBoxStyle.DropDownList,
                TabIndex      = 2
            };
            _roleCombo.Items.AddRange(new object[] { "Пользователь", "Администратор" });
            _roleCombo.SelectedIndex = 0;

            _okButton = new Button
            {
                Text         = "Сохранить",
                DialogResult = DialogResult.OK,
                Location     = new Point(110, 150),
                Size         = new Size(90, 30),
                TabIndex     = 3
            };
            _okButton.Click += OnOkClick;

            _cancelButton = new Button
            {
                Text         = "Отмена",
                DialogResult = DialogResult.Cancel,
                Location     = new Point(210, 150),
                Size         = new Size(90, 30),
                TabIndex     = 4
            };

            Controls.AddRange(new Control[]
            {
                loginLabel, _loginBox,
                _passwordLabel, _passwordBox,
                roleLabel, _roleCombo,
                _okButton, _cancelButton
            });

            AcceptButton = _okButton;
            CancelButton = _cancelButton;
        }

        private void OnOkClick(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_loginBox.Text))
            {
                MessageBox.Show("Поле «Логин» не может быть пустым.",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
                return;
            }

            if (!_isEdit && string.IsNullOrWhiteSpace(_passwordBox.Text))
            {
                MessageBox.Show("Поле «Пароль» не может быть пустым.",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.None;
                return;
            }

            UserLogin    = _loginBox.Text.Trim();
            UserPassword = _passwordBox.Text;
            UserRole     = _roleCombo.SelectedItem.ToString();
        }
    }
}