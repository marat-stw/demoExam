using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Кофейня.Data;
using Кофейня.Entities;

namespace Кофейня.Forms
{
    public class AdminForm : Form
    {
        private readonly User _currentAdmin;

        private DataGridView _usersGrid;
        private Button       _addUserButton;
        private Button       _editUserButton;
        private Button       _unblockUserButton;
        private Button       _refreshButton;
        private Label        _titleLabel;

        public AdminForm(User admin)
        {
            _currentAdmin = admin;
            InitializeComponent();
            LoadUsers();
        }

        private void InitializeComponent()
        {
            Text          = $"Кофейня Тёмная Материя — Администратор ({_currentAdmin.Login})";
            MinimumSize   = new Size(700, 500);
            Size          = new Size(800, 560);
            StartPosition = FormStartPosition.CenterScreen;

            _titleLabel = new Label
            {
                Text      = "Управление пользователями",
                Font      = new Font("Segoe UI", 14, FontStyle.Bold),
                Location  = new Point(20, 15),
                Size      = new Size(400, 30),
                ForeColor = Color.SteelBlue
            };

            _usersGrid = new DataGridView
            {
                Location              = new Point(20, 55),
                Anchor                = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                Size                  = new Size(760, 380),
                ReadOnly              = true,
                SelectionMode         = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect           = false,
                AllowUserToAddRows    = false,
                AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor       = Color.White,
                BorderStyle           = BorderStyle.Fixed3D
            };

            _addUserButton = new Button
            {
                Text     = "Добавить",
                Location = new Point(20, 450),
                Size     = new Size(120, 32),
                Anchor   = AnchorStyles.Bottom | AnchorStyles.Left,
                TabIndex = 0
            };
            _addUserButton.Click += OnAddUserClick;

            _editUserButton = new Button
            {
                Text     = "Редактировать",
                Location = new Point(155, 450),
                Size     = new Size(140, 32),
                Anchor   = AnchorStyles.Bottom | AnchorStyles.Left,
                TabIndex = 1
            };
            _editUserButton.Click += OnEditUserClick;

            _unblockUserButton = new Button
            {
                Text      = "Снять блокировку",
                Location  = new Point(310, 450),
                Size      = new Size(160, 32),
                Anchor    = AnchorStyles.Bottom | AnchorStyles.Left,
                TabIndex  = 2,
                BackColor = Color.LightGreen
            };
            _unblockUserButton.Click += OnUnblockClick;

            _refreshButton = new Button
            {
                Text     = "Обновить",
                Location = new Point(660, 450),
                Size     = new Size(100, 32),
                Anchor   = AnchorStyles.Bottom | AnchorStyles.Right,
                TabIndex = 3
            };
            _refreshButton.Click += (s, e) => LoadUsers();

            Controls.AddRange(new Control[]
            {
                _titleLabel, _usersGrid,
                _addUserButton, _editUserButton, _unblockUserButton, _refreshButton
            });
        }

        private void LoadUsers()
        {
            _usersGrid.DataSource = DatabaseHelper.GetAllUsers();
        }

        private void OnAddUserClick(object sender, EventArgs e)
        {
            using (var dialog = new UserEditDialog())
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;

                if (DatabaseHelper.LoginExists(dialog.UserLogin))
                {
                    MessageBox.Show(
                        $"Пользователь с логином «{dialog.UserLogin}» уже существует.\nВыберите другой логин.",
                        "Дублирование", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DatabaseHelper.AddUser(dialog.UserLogin, dialog.UserPassword, dialog.UserRole);
                LoadUsers();
                MessageBox.Show("Пользователь успешно добавлен.",
                    "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void OnEditUserClick(object sender, EventArgs e)
        {
            if (_usersGrid.CurrentRow == null) return;

            int    userId = Convert.ToInt32(_usersGrid.CurrentRow.Cells["Id"].Value);
            string login  = _usersGrid.CurrentRow.Cells["Login"].Value.ToString();
            string role   = _usersGrid.CurrentRow.Cells["Role"].Value.ToString();

            using (var dialog = new UserEditDialog(login, role))
            {
                if (dialog.ShowDialog() != DialogResult.OK) return;
                DatabaseHelper.UpdateUser(userId, dialog.UserLogin, dialog.UserRole);
                LoadUsers();
            }
        }

        private void OnUnblockClick(object sender, EventArgs e)
        {
            if (_usersGrid.CurrentRow == null) return;

            int userId = Convert.ToInt32(_usersGrid.CurrentRow.Cells["Id"].Value);
            DatabaseHelper.UnblockUser(userId);
            LoadUsers();
            MessageBox.Show("Блокировка снята.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}