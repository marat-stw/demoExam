-- ============================================================================
-- ЧАСТЬ 1: СОЗДАНИЕ БАЗЫ ДАННЫХ И ТАБЛИЦ
-- ============================================================================

CREATE DATABASE ПроизводствоЗаказов;
GO

USE ПроизводствоЗаказов;
GO

-- 2. Создание таблицы "Заказчики"
CREATE TABLE Заказчики (
    id_заказчика VARCHAR(20) NOT NULL,
    наименование NVARCHAR(255) NOT NULL,
    инн VARCHAR(20) NULL,
    адрес NVARCHAR(255) NULL,
    телефон VARCHAR(20) NULL,
    является_продавцом BIT NOT NULL DEFAULT 0,
    является_покупателем BIT NOT NULL DEFAULT 0,
    CONSTRAINT PK_Заказчики PRIMARY KEY (id_заказчика)
);

-- 3. Создание таблицы "Заказ_покупателя"
CREATE TABLE Заказ_покупателя (
    id_заказ_покупателя INT IDENTITY(1,1) NOT NULL,
    id_заказа INT NOT NULL,
    id_заказчика VARCHAR(20) NOT NULL,
    дата_заказа DATE NOT NULL,
    сумма_итого INT NOT NULL,
    CONSTRAINT PK_Заказ_покупателя PRIMARY KEY (id_заказ_покупателя),
    CONSTRAINT FK_Заказ_Заказчики FOREIGN KEY (id_заказчика) 
        REFERENCES Заказчики(id_заказчика) ON DELETE CASCADE
);

-- 4. Создание таблицы "Продукция"
CREATE TABLE Продукция (
    id_продукции INT IDENTITY(1,1) NOT NULL,
    наименование NVARCHAR(255) NOT NULL,
    единица_измерения NVARCHAR(50) NOT NULL,
    цена NUMERIC(15, 2) NOT NULL,
    CONSTRAINT PK_Продукция PRIMARY KEY (id_продукции)
);

-- 5. Создание таблицы "Строки_заказа"
CREATE TABLE Строки_заказа (
    id_строки INT IDENTITY(1,1) NOT NULL,
    id_заказа INT NOT NULL,
    id_продукции INT NOT NULL,
    количество NUMERIC(15, 3) NOT NULL,
    CONSTRAINT PK_Строки_заказа PRIMARY KEY (id_строки),
    CONSTRAINT FK_Строки_Продукция FOREIGN KEY (id_продукции) 
        REFERENCES Продукция(id_продукции) ON DELETE CASCADE
);

-- 6. Создание таблицы "Материалы"
CREATE TABLE Материалы (
    id_материала INT IDENTITY(1,1) NOT NULL,
    наименование NVARCHAR(255) NOT NULL,
    единица_измерения NVARCHAR(50) NOT NULL,
    цена INT NOT NULL,
    CONSTRAINT PK_Материалы PRIMARY KEY (id_материала)
);

-- 7. Создание таблицы "Спецификация"
CREATE TABLE Спецификация (
    id_спецификации INT IDENTITY(1,1) NOT NULL,
    id_продукции INT NOT NULL,
    id_материала INT NOT NULL,
    норма_расхода NUMERIC(15, 4) NOT NULL,
    CONSTRAINT PK_Спецификация PRIMARY KEY (id_спецификации),
    CONSTRAINT FK_Спецификация_Продукция FOREIGN KEY (id_продукции) 
        REFERENCES Продукция(id_продукции) ON DELETE CASCADE,
    CONSTRAINT FK_Спецификация_Материалы FOREIGN KEY (id_материала) 
        REFERENCES Материалы(id_материала) ON DELETE CASCADE
);
GO


-- ============================================================================
-- ЧАСТЬ 2: ИМПОРТ ДАННЫХ ИЗ Заказчики.json ЧЕРЕЗ ИНСЕРТ
-- ============================================================================

INSERT INTO Заказчики (id_заказчика, наименование, инн, адрес, телефон, является_продавцом, является_покупателем)
VALUES 
    ('0000000001', N'ООО "Поставка"', NULL, N'г. Пятигорск', '+79198634592', 1, 1),
    ('0000000002', N'ООО "Кинотеатр Квант"', '26320045123', N'г. Железноводск, ул. Мира, 123', '+79884581555', 1, 0),
    ('0000000008', N'ООО "Новый JDTO"', '26320045111', N'г. Железноводск', '+79884581555', 1, 0),
    ('0000000003', N'ООО "Ромашка"', '4140784214', N'г. Омск, ул. Строителей, 294', '+79882584546', 0, 1),
    ('0000000009', N'ООО "Ипподром"', '5874045632', N'г. Уфа, ул. Набережная, 37', '+79627486389', 1, 1),
    ('00000000010', N'ООО "Ассоль"', '2629011278', N'г. Калуга, ул. Пушкина, 94', '+79184572398', 0, 1);
GO

-- Проверяем результат импорта
SELECT * FROM Заказчики;

-- СОЗДАНИЕ ЗАПРОСА (3 ЗАДАНИЕ)

SELECT 
    Строки_заказа.id_заказа,
    SUM(Строки_заказа.количество * СебестоимостьТовара.себестоимость_единицы) AS полная_стоимость_заказа
FROM Строки_заказа
INNER JOIN (
    SELECT 
        Спецификация.id_продукции,
        SUM(Спецификация.норма_расхода * Материалы.цена) AS себестоимость_единицы
    FROM Спецификация
    INNER JOIN Материалы ON Спецификация.id_материала = Материалы.id_материала
    GROUP BY Спецификация.id_продукции
) AS СебестоимостьТовара ON Строки_заказа.id_продукции = СебестоимостьТовара.id_продукции
GROUP BY Строки_заказа.id_заказа;

-- ДЛЯ 4 ЗАДАНИЯ КОД

USE Производство;
GO

CREATE TABLE Пользователи (
    Id             INT           NOT NULL IDENTITY(1,1),
    Login          VARCHAR(100)  NOT NULL UNIQUE,
    Password       VARCHAR(255)  NOT NULL,
    Role           VARCHAR(50)   NOT NULL DEFAULT 'Пользователь',
    IsBlocked      BIT           NOT NULL DEFAULT 0,
    FailedAttempts INT           NOT NULL DEFAULT 0,
    CONSTRAINT PK_Пользователи PRIMARY KEY (Id)
);
GO

-- Тестовые пользователи
INSERT INTO Пользователи (Login, Password, Role) VALUES
    ('admin', 'admin123', 'Администратор'),
    ('user1', 'user123',  'Пользователь');
GO
